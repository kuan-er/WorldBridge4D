import numpy as np

from worldbridge.data import MOViFDataset
from worldbridge.evaluation512 import apply_sim3, estimate_sim3, evaluate_clip_tracks, native_flat_pixels


def test_st4rtrack_sim3_recovers_proper_shared_transform():
    rng = np.random.default_rng(20260815)
    prediction = rng.normal(size=(4096, 3))
    angle = 0.71
    rotation = np.array([
        [np.cos(angle), 0.0, np.sin(angle)],
        [0.0, 1.0, 0.0],
        [-np.sin(angle), 0.0, np.cos(angle)],
    ])
    scale = 2.4
    translation = np.array([1.2, -0.8, 3.1])
    truth = apply_sim3(prediction, scale, rotation, translation)

    fitted_scale, fitted_rotation, fitted_translation = estimate_sim3(prediction, truth)
    aligned = apply_sim3(prediction, fitted_scale, fitted_rotation, fitted_translation)

    assert abs(fitted_scale - scale) < 1e-12
    assert np.max(np.abs(fitted_rotation - rotation)) < 1e-12
    assert np.max(np.abs(fitted_translation - translation)) < 1e-12
    assert np.max(np.abs(aligned - truth)) < 1e-11
    assert np.linalg.det(fitted_rotation) > 0.999999


def test_st4rtrack_sim3_forbids_reflection():
    rng = np.random.default_rng(20260816)
    prediction = rng.normal(size=(1024, 3))
    truth = prediction.copy()
    truth[:, 0] *= -1

    _, rotation, _ = estimate_sim3(prediction, truth)

    assert np.linalg.det(rotation) > 0.999999


def test_native_512_sampling_does_not_use_a_128_grid():
    flat = native_flat_pixels(512, 512, 16)
    assert len(flat) == 512 * 512 // 16
    assert flat[0] == 0
    assert flat[-1] == 512 * 512 - 16
    assert int(flat.max() // 512) == 511


def test_dataset_resolution_selector_chooses_512_instead_of_historical_128(tmp_path):
    version128 = tmp_path / "128x128" / "1.0.0"
    version512 = tmp_path / "512x512" / "1.0.0"
    version128.mkdir(parents=True)
    version512.mkdir(parents=True)
    (version128 / "features.json").write_text("{}")
    (version512 / "features.json").write_text("{}")

    assert MOViFDataset._find_version_dir(tmp_path) == version128
    assert MOViFDataset._find_version_dir(tmp_path, (512, 512)) == version512


def test_one_clip_sim3_is_shared_across_all_sources_and_subsets():
    rng = np.random.default_rng(20260817)
    sources = [0, 1, 2]
    prediction = rng.normal(size=(3, 3, 17, 3)).astype(np.float32)
    angle = 0.31
    rotation = np.array([
        [np.cos(angle), -np.sin(angle), 0.0],
        [np.sin(angle), np.cos(angle), 0.0],
        [0.0, 0.0, 1.0],
    ])
    truth = apply_sim3(prediction, 1.7, rotation, np.array([0.2, -0.4, 1.1])).astype(np.float32)
    valid = np.ones(prediction.shape[:-1], dtype=bool)
    visible = np.ones_like(valid)
    visible[:, :, ::3] = False
    late = np.zeros((3, 17), dtype=bool)
    late[1:, :4] = True

    result = evaluate_clip_tracks(prediction, truth, valid, visible, sources, late)

    assert result["alignment"]["fit_source_target_pairs"] == 9
    assert result["alignment"]["fit_points"] == 3 * 3 * 17
    assert result["clip_sim3_closed"]["arbitrary_all_st"]["epe_m"] < 2e-6
    assert result["clip_sim3_closed"]["pointmap"]["epe_m"] < 2e-6
    assert result["clip_sim3_closed"]["tracking_occluded_valid"]["epe_m"] < 2e-6
    assert result["raw_unaligned"]["arbitrary_all_st"]["epe_m"] > 0.1
