#!/usr/bin/env python3
"""Run released 4RC on native 512x512 MOVi-F with all-source tracking."""
from __future__ import annotations

import argparse
import gc
import json
import pathlib
import sys
import tempfile
import time

import numpy as np
import torch
from PIL import Image

# Reuse the native-record decoder and metric implementation from the sibling
# protocol adapter. This module does not import the 4RC package until after the
# model is constructed below.
from evaluate_4rc_kubric import (
    _bytes, _read_records, evaluate_arrays, resolve_version, sample_from_example,
)


def _sample_tracks(output, n_frames: int, queries: list[int], flat: np.ndarray,
                   native_hw: tuple[int, int]) -> tuple[np.ndarray, list[int]]:
    height, width = native_hw
    sampled = np.empty((n_frames, len(queries), len(flat), 3), dtype=np.float32)
    output_hw = None
    u0, v0 = flat % width, flat // width
    for target, pred in enumerate(output["preds"]):
        tracks = pred.get("track_multi")
        if tracks is None:
            tracks = pred["track"].unsqueeze(0)
        tracks = tracks.detach().cpu().numpy()
        if tracks.ndim == 5:
            tracks = tracks[0]
        if tracks.shape[0] != len(queries) or tracks.shape[-1] != 3:
            raise RuntimeError(f"unexpected track shape at target {target}: {tracks.shape}")
        hp, wp = tracks.shape[1:3]
        output_hw = [int(hp), int(wp)]
        # 4RC's patch grid may be 504x504 for a native 512 image. Map native
        # source-pixel centres once by the released evaluator convention; no
        # 128 intermediate grid or prediction resize is used.
        up = np.clip((u0 * wp / width).astype(np.int64), 0, wp - 1)
        vp = np.clip((v0 * hp / height).astype(np.int64), 0, hp - 1)
        sampled[target] = tracks[:, vp, up]
    return sampled, output_hw


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-root", default="/dataset/nas0/yejun/MOVi-F/512x512")
    ap.add_argument("--split", default="validation", choices=("train", "validation"))
    ap.add_argument("--output", required=True)
    ap.add_argument("--max-clips", type=int, default=147)
    ap.add_argument("--dataset-offset", type=int, default=0)
    ap.add_argument("--clip-start", type=int, default=0)
    ap.add_argument("--clip-length", type=int, default=21)
    ap.add_argument("--size", type=int, default=512)
    ap.add_argument("--patch-size", type=int, default=14)
    ap.add_argument("--pixel-stride", type=int, default=16)
    ap.add_argument("--fourrc-root", default="/data/4RC")
    ap.add_argument(
        "--checkpoint-dir",
        default="/data/WorldBridge4D-persistent/external_checkpoints/4RC",
    )
    args = ap.parse_args()
    if args.max_clips < 1 or args.dataset_offset < 0 or args.pixel_stride < 1:
        raise ValueError("max-clips/pixel-stride must be positive and dataset-offset non-negative")
    if args.size != 512 or args.clip_length != 21:
        raise ValueError("native-512 protocol requires --size 512 and --clip-length 21")

    sys.path.insert(0, str(pathlib.Path(args.fourrc_root).resolve()))
    from arc.models.arc import Arc
    from arc.dust3r.inference_multiview import inference
    from arc.dust3r.utils.image import load_images

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = Arc.from_pretrained(args.checkpoint_dir).to(device).eval()
    flat = np.arange(0, 512 * 512, int(args.pixel_stride), dtype=np.int64)
    queries = list(range(args.clip_length))
    version = resolve_version(pathlib.Path(args.data_root), 512)
    shards = sorted(version.glob(f"movi_f-{args.split}.tfrecord-*"))
    if not shards:
        raise FileNotFoundError(f"No {args.split} TFRecords below {version}")

    pooled = {
        "raw_unaligned": {}, "clip_sim3_closed": {},
        "raw_epe_by_temporal_gap": {}, "clip_sim3_closed_epe_by_temporal_gap": {},
    }
    per_clip = []
    times = []
    seen = 0
    processed = 0
    started = time.time()
    with tempfile.TemporaryDirectory(prefix="4rc_kubric_frames_") as temp_root:
        for shard in shards:
            for ex in _read_records(shard):
                if seen < args.dataset_offset:
                    seen += 1
                    continue
                if processed >= args.max_clips:
                    break
                dataset_index = seen
                sample = sample_from_example(ex, args.clip_start, args.clip_length, expected_resolution=512)
                clip_dir = pathlib.Path(temp_root) / f"{dataset_index:05d}"
                clip_dir.mkdir()
                paths = []
                for t, encoded in enumerate(_bytes(ex, "video")[args.clip_start:args.clip_start + args.clip_length]):
                    path = clip_dir / f"{t:03d}.png"
                    with Image.open(__import__("io").BytesIO(encoded)) as image:
                        image.convert("RGB").save(path)
                    paths.append(str(path))
                imgs = load_images(paths, size=args.size, square_ok=True, verbose=False, patch_size=args.patch_size)
                if len(imgs) != args.clip_length:
                    raise ValueError(f"4RC loader returned {len(imgs)} views, expected {args.clip_length}")
                query_tensor = torch.tensor(queries, dtype=torch.long)
                for img in imgs:
                    img["track_query_idx"] = query_tensor
                start = time.time()
                with torch.no_grad():
                    output, profiling = inference(
                        imgs, model, device, dtype="bf16-mixed", profiling=True,
                        verbose=False, use_center_as_anchor=False,
                    )
                elapsed = time.time() - start
                sampled, output_hw = _sample_tracks(
                    output, args.clip_length, queries, flat, (sample.height, sample.width)
                )
                metrics = evaluate_arrays(sample, sampled, np.asarray(queries), flat)
                metrics.update({"dataset_index": dataset_index, "video_name": sample.video_name,
                                "profiling_total_time": float(profiling["total_time"]),
                                "wall_inference_seconds": float(elapsed), "output_hw": output_hw})
                per_clip.append(metrics)
                times.append(elapsed)
                for namespace in pooled:
                    source_metrics = metrics[namespace]
                    for name, value in source_metrics.items():
                        dst = pooled[namespace].setdefault(name, {"sum": 0.0, "points": 0, "clips": []})
                        if value["epe_m"] is not None:
                            dst["sum"] += value["epe_m"] * value["points"]
                            dst["points"] += value["points"]
                            dst["clips"].append(value["epe_m"])
                processed += 1
                seen += 1
                del output, imgs, sampled, sample
                gc.collect()
                if device.type == "cuda":
                    torch.cuda.empty_cache()
                print(json.dumps({
                    "dataset_index": dataset_index, "processed": processed,
                    "total": args.max_clips, "video_name": per_clip[-1]["video_name"],
                    "wall_inference_seconds": elapsed,
                    "arbitrary_all_st_epe_sim3": metrics["clip_sim3_closed"]["arbitrary_all_st"]["epe_m"],
                }), flush=True)
            if processed >= args.max_clips:
                break
    if processed != args.max_clips:
        raise RuntimeError(f"requested {args.max_clips} clips at offset {args.dataset_offset}, processed {processed}")

    summary = {}
    for namespace, metrics in pooled.items():
        summary[namespace] = {}
        for name, value in metrics.items():
            clips = np.asarray(value["clips"], dtype=np.float64)
            summary[namespace][name] = {
                "pooled_epe": float(value["sum"] / max(value["points"], 1)),
                "mean_clip_epe": float(clips.mean()) if len(clips) else None,
                "std_clip_epe": float(clips.std()) if len(clips) else None,
                "clips": int(len(clips)), "points": int(value["points"]),
            }
    result = {
        "method": "4RC",
        "checkpoint_dir": args.checkpoint_dir,
        "fourrc_root": str(pathlib.Path(args.fourrc_root).resolve()),
        "protocol": {
            "data_root": str(version), "split": args.split, "dataset_offset": args.dataset_offset,
            "clips": processed, "clip_length": args.clip_length, "clip_start": args.clip_start,
            "native_resolution": [512, 512],
            "pixel_stride": args.pixel_stride,
            "sampled_native_pixels_per_pair": int(len(flat)),
            "query_indices": queries, "pair_count": len(queries) * args.clip_length,
            "input_size": args.size, "input_crop": "none; square_ok=True",
            "metric_grid": "native 512x512 source pixels; direct mapping to the released patch grid; no 128 intermediate",
            "alignment": "one oracle proper closed-form Sim(3) per clip over all 441 pairs; shared by every subset",
            "validity_mask": "WorldBridge A; occluded valid points retained",
        },
        "summary": summary,
        "timing": {"total_wall_seconds": time.time() - started,
                   "mean_clip_inference_seconds": float(np.mean(times)),
                   "std_clip_inference_seconds": float(np.std(times))},
        "per_clip": per_clip,
    }
    output = pathlib.Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2))
    print(json.dumps({"method": "4RC", "clips": processed, "summary": summary, "timing": result["timing"]}, indent=2), flush=True)
    print(f"RUN_4RC_KUBRIC_VALIDATION_OK: {output}", flush=True)


if __name__ == "__main__":
    main()
