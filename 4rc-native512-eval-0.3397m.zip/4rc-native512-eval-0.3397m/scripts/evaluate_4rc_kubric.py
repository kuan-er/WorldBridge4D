#!/usr/bin/env python3
"""Evaluate sampled 4RC tracks on native 512x512 MOVi-F geometry."""
from __future__ import annotations

import argparse
import io
import json
import pathlib
import sys

import numpy as np
from PIL import Image
from tensorflow.core.example.example_pb2 import Example

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from worldbridge.data import MOViSample  # noqa: E402
from worldbridge.evaluation512 import evaluate_clip_tracks  # noqa: E402
from worldbridge.geometry import GeometryBuilder  # noqa: E402


def _feature(ex: Example, key: str, kind: str, dtype) -> np.ndarray:
    return np.asarray(getattr(ex.features.feature[key], kind).value, dtype=dtype)


def _bytes(ex: Example, key: str) -> list[bytes]:
    return list(ex.features.feature[key].bytes_list.value)


def _read_records(path: pathlib.Path):
    with path.open("rb") as handle:
        while True:
            header = handle.read(12)
            if not header:
                return
            if len(header) != 12:
                raise IOError(f"truncated TFRecord header in {path}")
            length = int.from_bytes(header[:8], "little")
            payload = handle.read(length)
            if len(payload) != length or len(handle.read(4)) != 4:
                raise IOError(f"truncated TFRecord payload in {path}")
            yield Example.FromString(payload)


def _decode_png(encoded: bytes, mode: str) -> np.ndarray:
    with Image.open(io.BytesIO(encoded)) as image:
        if mode == "rgb":
            return np.asarray(image.convert("RGB"), dtype=np.uint8)
        return np.asarray(image, dtype=np.uint16)


def sample_from_example(ex: Example, clip_start: int, clip_length: int,
                        expected_resolution: int = 512) -> MOViSample:
    """Decode one native TFRecord Example without importing TensorFlow."""
    i64 = lambda key: _feature(ex, key, "int64_list", np.int64)
    f32 = lambda key: _feature(ex, key, "float_list", np.float32)
    total_t = int(i64("metadata/num_frames")[0])
    height, width = int(i64("metadata/height")[0]), int(i64("metadata/width")[0])
    if (height, width) != (expected_resolution, expected_resolution):
        raise ValueError(
            f"native-512 protocol rejects TFRecord resolution {(height, width)}"
        )
    n_instances = int(i64("metadata/num_instances")[0])
    if not (0 <= clip_start <= total_t - clip_length):
        raise ValueError(f"invalid clip start {clip_start} for native T={total_t}")
    sl = slice(clip_start, clip_start + clip_length)
    video, depth_png, seg_png = _bytes(ex, "video"), _bytes(ex, "depth"), _bytes(ex, "segmentations")
    if not (len(video) == len(depth_png) == len(seg_png) == total_t):
        raise ValueError("native frame feature lengths disagree")
    rgb = np.stack([_decode_png(value, "rgb") for value in video[sl]], axis=0)
    depth_raw = np.stack([
        _decode_png(value, "depth").reshape(height, width) for value in depth_png[sl]
    ], axis=0)
    segmentation = np.stack([
        _decode_png(value, "depth").reshape(height, width) for value in seg_png[sl]
    ], axis=0).astype(np.int64)
    depth_range = f32("metadata/depth_range")
    depth = depth_range[0] + depth_raw.astype(np.float32) / np.float32(65535.0) \
        * (depth_range[1] - depth_range[0])
    depth_valid = np.isfinite(depth) & (depth > 0) & (depth_raw > 0)
    return MOViSample(
        video_name=_bytes(ex, "metadata/video_name")[0].decode("utf8"), rgb=rgb,
        depth=depth.astype(np.float32), depth_valid=depth_valid,
        segmentation=segmentation,
        camera_positions=f32("camera/positions").reshape(total_t, 3)[sl].astype(np.float32),
        camera_quaternions=f32("camera/quaternions").reshape(total_t, 4)[sl].astype(np.float32),
        focal_length=float(f32("camera/focal_length")[0]),
        sensor_width=float(f32("camera/sensor_width")[0]),
        field_of_view=float(f32("camera/field_of_view")[0]),
        instance_positions=f32("instances/positions").reshape(n_instances, total_t, 3)[:, sl].astype(np.float32),
        instance_quaternions=f32("instances/quaternions").reshape(n_instances, total_t, 4)[:, sl].astype(np.float32),
        instance_dynamic=i64("instances/is_dynamic").astype(bool),
        instance_visibility=i64("instances/visibility").reshape(n_instances, total_t)[:, sl].astype(np.uint16),
        depth_range=depth_range.astype(np.float32), clip_start=clip_start,
    )


def resolve_version(data_root: pathlib.Path, resolution: int = 512) -> pathlib.Path:
    if (data_root / "features.json").exists():
        return data_root
    base = data_root / f"{resolution}x{resolution}"
    if not base.is_dir():
        base = data_root
    candidates = sorted(base.glob("*/features.json"))
    if not candidates:
        raise FileNotFoundError(f"No native {resolution}x{resolution} MOVi-F features.json below {data_root}")
    return candidates[-1].parent


def load_sample(data_root: pathlib.Path, split: str, index: int, clip_start: int,
                clip_length: int) -> MOViSample:
    version = resolve_version(data_root, 512)
    shards = sorted(version.glob(f"movi_f-{split}.tfrecord-*"))
    if not shards:
        raise FileNotFoundError(f"No {split} TFRecords below {version}")
    seen = 0
    for shard in shards:
        for example in _read_records(shard):
            if seen == index:
                return sample_from_example(example, clip_start, clip_length)
            seen += 1
    raise IndexError(index)


def _late_pixels(sample: MOViSample, source: int, flat: np.ndarray) -> np.ndarray:
    ids = sample.segmentation[source]
    first_visible = np.full(ids.shape, sample.num_frames, dtype=np.int64)
    for instance_id in np.unique(ids):
        if 0 < instance_id <= sample.num_instances:
            seen = np.flatnonzero(sample.instance_visibility[instance_id - 1] > 0)
            if len(seen):
                first_visible[ids == instance_id] = int(seen[0])
    late = (
        (first_visible > 0) & (first_visible < sample.num_frames)
        & (source >= first_visible)
    )
    return late.reshape(-1)[flat]


def evaluate_arrays(sample: MOViSample, prediction: np.ndarray, queries: np.ndarray,
                    flat: np.ndarray) -> dict:
    """Evaluate 4RC ``[target,source_slot,pixel,xyz]`` sampled predictions."""
    prediction = np.asarray(prediction, dtype=np.float32)
    queries = np.asarray(queries, dtype=np.int64)
    flat = np.asarray(flat, dtype=np.int64)
    if prediction.shape != (sample.num_frames, len(queries), len(flat), 3):
        raise ValueError(
            f"prediction {prediction.shape} incompatible with T={sample.num_frames}, "
            f"Q={len(queries)}, P={len(flat)}"
        )
    if len(flat) == 0 or flat.min() < 0 or flat.max() >= sample.height * sample.width:
        raise ValueError("source pixels fall outside native grid")
    uv = np.stack([flat % sample.width, flat // sample.width], axis=-1)
    geometry = GeometryBuilder(sample)
    truth, visible, valid, late = [], [], [], []
    for source in queries:
        xyz, source_visible, source_valid = geometry.trajectory(int(source), uv)
        truth.append(xyz.transpose(1, 0, 2))
        visible.append(source_visible.transpose(1, 0))
        valid.append(source_valid.transpose(1, 0))
        late.append(_late_pixels(sample, int(source), flat))
    result = evaluate_clip_tracks(
        prediction.transpose(1, 0, 2, 3), np.stack(truth), np.stack(valid),
        np.stack(visible), queries, np.stack(late),
    )
    result["protocol"] = {
        "dataset": "Kubric MOVi-F native 512x512",
        "native_resolution": [sample.height, sample.width],
        "sources": queries.tolist(), "pair_count": int(len(queries) * sample.num_frames),
        "sampled_native_pixels_per_pair": len(flat),
        "pixel_stride": int(flat[1] - flat[0]) if len(flat) > 1 else None,
        "validity": "WorldBridge A; occluded-valid retained",
        "alignment": "one oracle proper closed-form Sim(3) per clip over all selected pairs",
    }
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", default="/dataset/nas0/yejun/MOVi-F/512x512")
    parser.add_argument("--split", default="validation", choices=("train", "validation"))
    parser.add_argument("--dataset-index", type=int, default=0)
    parser.add_argument("--clip-start", type=int, default=0)
    parser.add_argument("--clip-length", type=int, default=21)
    parser.add_argument("--prediction", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    sample = load_sample(
        pathlib.Path(args.data_root), args.split, args.dataset_index,
        args.clip_start, args.clip_length,
    )
    values = np.load(args.prediction)
    result = evaluate_arrays(
        sample, values["pred_tracks"], values["query_indices"],
        values["source_flat_pixels"],
    )
    result["protocol"].update({
        "split": args.split, "dataset_index": args.dataset_index,
        "clip_start": args.clip_start,
    })
    result["prediction"] = str(pathlib.Path(args.prediction).resolve())
    output = pathlib.Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2))
    print(f"EVALUATE_4RC_KUBRIC_512_OK: {output}", flush=True)


if __name__ == "__main__":
    main()
