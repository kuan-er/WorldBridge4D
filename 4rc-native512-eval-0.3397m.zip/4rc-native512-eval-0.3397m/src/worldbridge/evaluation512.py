"""Shared native-resolution arbitrary-source tracking evaluation utilities.

The protocol keeps predictions and GT in a common clip-frame-0 camera basis,
fits one proper closed-form Sim(3) over every selected valid point in the clip,
and reuses that transform for every metric subset.  The fit is an oracle gauge
diagnostic and is deliberately named ``clip_sim3_closed`` rather than the
separate 4RC RANSAC benchmark protocol.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Any, Sequence

import numpy as np


def native_flat_pixels(height: int, width: int, pixel_stride: int) -> np.ndarray:
    """Return deterministic flat native-grid pixels without spatial resizing."""
    height, width, pixel_stride = int(height), int(width), int(pixel_stride)
    if height < 1 or width < 1 or pixel_stride < 1:
        raise ValueError("height, width, and pixel_stride must be positive")
    return np.arange(0, height * width, pixel_stride, dtype=np.int64)


def estimate_sim3(prediction: np.ndarray, truth: np.ndarray) -> tuple[float, np.ndarray, np.ndarray]:
    """Return proper ``s, R, t`` for ``truth ~= s * prediction @ R.T + t``."""
    prediction = np.asarray(prediction, dtype=np.float64)
    truth = np.asarray(truth, dtype=np.float64)
    if prediction.ndim != 2 or prediction.shape[1] != 3 or truth.shape != prediction.shape:
        raise ValueError(f"Sim(3) requires matched [N,3], got {prediction.shape}/{truth.shape}")
    if len(prediction) < 3:
        raise ValueError("Sim(3) requires at least three correspondences")
    pred_mean = prediction.mean(axis=0)
    truth_mean = truth.mean(axis=0)
    x = prediction - pred_mean
    y = truth - truth_mean
    covariance = x.T @ y / len(x)
    u, singular, vt = np.linalg.svd(covariance)
    correction = np.ones(3, dtype=np.float64)
    if np.linalg.det(vt.T @ u.T) < 0:
        correction[-1] = -1.0
    rotation = vt.T @ np.diag(correction) @ u.T
    variance = float(np.sum(x * x) / len(x))
    if variance <= 1e-12:
        raise ValueError(f"degenerate Sim(3) prediction variance: {variance}")
    scale = float(np.sum(singular * correction) / variance)
    translation = truth_mean - scale * (rotation @ pred_mean)
    if scale <= 0 or not (
        np.isfinite(scale) and np.isfinite(rotation).all() and np.isfinite(translation).all()
    ):
        raise ValueError("invalid proper Sim(3) fit")
    return scale, rotation, translation


def apply_sim3(points: np.ndarray, scale: float, rotation: np.ndarray,
               translation: np.ndarray) -> np.ndarray:
    return scale * (np.asarray(points) @ np.asarray(rotation).T) + np.asarray(translation)


def _add(store: dict[str, dict[str, float]], name: str, error: np.ndarray,
         mask: np.ndarray) -> None:
    mask = np.asarray(mask, dtype=bool)
    if not np.any(mask):
        return
    row = store.setdefault(name, {"sum": 0.0, "points": 0.0})
    row["sum"] += float(np.asarray(error)[mask].sum(dtype=np.float64))
    row["points"] += float(mask.sum())


def _finish(store: dict[str, dict[str, float]]) -> dict[str, dict[str, float | int]]:
    return {
        name: {"epe_m": row["sum"] / row["points"], "points": int(row["points"])}
        for name, row in sorted(store.items()) if row["points"]
    }


def evaluate_clip_tracks(
    prediction: np.ndarray,
    truth: np.ndarray,
    valid: np.ndarray,
    visible: np.ndarray,
    sources: Sequence[int],
    late_appearing: np.ndarray | None = None,
) -> dict[str, Any]:
    """Evaluate sampled source-grid tracks for one clip.

    Arrays use ``[source_slot,target,pixel,xyz]`` and masks use
    ``[source_slot,target,pixel]``. ``sources`` maps source slots to physical
    frame indices. Predictions and truth must already share the frame-0 anchor.
    """
    prediction = np.asarray(prediction, dtype=np.float32)
    truth = np.asarray(truth, dtype=np.float32)
    valid = np.asarray(valid, dtype=bool)
    visible = np.asarray(visible, dtype=bool)
    sources = np.asarray(sources, dtype=np.int64)
    if prediction.ndim != 4 or prediction.shape[-1] != 3 or truth.shape != prediction.shape:
        raise ValueError(f"expected matched [S,T,P,3], got {prediction.shape}/{truth.shape}")
    if valid.shape != prediction.shape[:-1] or visible.shape != valid.shape:
        raise ValueError("valid/visible shapes do not match track arrays")
    slots, frames, pixels = valid.shape
    if sources.shape != (slots,) or np.any(sources < 0) or np.any(sources >= frames):
        raise ValueError(f"invalid physical sources {sources.tolist()} for T={frames}")
    if late_appearing is None:
        late_appearing = np.zeros((slots, pixels), dtype=bool)
    late_appearing = np.asarray(late_appearing, dtype=bool)
    if late_appearing.shape != (slots, pixels):
        raise ValueError(f"late_appearing must be {(slots, pixels)}, got {late_appearing.shape}")

    finite = np.isfinite(prediction).all(axis=-1) & np.isfinite(truth).all(axis=-1)
    fit_mask = valid & finite
    scale, rotation, translation = estimate_sim3(prediction[fit_mask], truth[fit_mask])
    aligned = apply_sim3(prediction, scale, rotation, translation).astype(np.float32)
    raw_error = np.linalg.norm(prediction - truth, axis=-1)
    aligned_error = np.linalg.norm(aligned - truth, axis=-1)

    target = np.arange(frames, dtype=np.int64)[None, :, None]
    source = sources[:, None, None]
    diagonal = target == source
    off_diagonal = ~diagonal
    source_zero = np.broadcast_to(source == 0, valid.shape)
    late = np.broadcast_to(late_appearing[:, None, :], valid.shape)
    groups = {
        "arbitrary_all_st": np.ones(valid.shape, dtype=bool),
        "pointmap": np.broadcast_to(diagonal, valid.shape),
        "tracking": np.broadcast_to(off_diagonal, valid.shape),
        "first_frame_tracking": source_zero,
        "tracking_source_zero": source_zero & np.broadcast_to(off_diagonal, valid.shape),
        "tracking_source_gt_zero": (~source_zero) & np.broadcast_to(off_diagonal, valid.shape),
        "late_appearing": late,
    }
    results = {}
    for namespace, error in (("raw_unaligned", raw_error), ("clip_sim3_closed", aligned_error)):
        store: dict[str, dict[str, float]] = {}
        for name, group in groups.items():
            mask = fit_mask & group
            _add(store, name, error, mask)
            _add(store, name + "_visible", error, mask & visible)
            _add(store, name + "_occluded_valid", error, mask & ~visible)
        results[namespace] = _finish(store)

    raw_gap: dict[str, dict[str, float]] = defaultdict(lambda: {"sum": 0.0, "points": 0.0})
    aligned_gap: dict[str, dict[str, float]] = defaultdict(lambda: {"sum": 0.0, "points": 0.0})
    for slot, physical_source in enumerate(sources):
        for target_index in range(frames):
            gap = abs(int(target_index) - int(physical_source))
            if gap == 0:
                continue
            mask = fit_mask[slot, target_index]
            _add(raw_gap, str(gap), raw_error[slot, target_index], mask)
            _add(aligned_gap, str(gap), aligned_error[slot, target_index], mask)
    results["raw_epe_by_temporal_gap"] = _finish(raw_gap)
    results["clip_sim3_closed_epe_by_temporal_gap"] = _finish(aligned_gap)
    results["alignment"] = {
        "scale": scale,
        "rotation": rotation.tolist(),
        "translation": translation.tolist(),
        "fit_points": int(fit_mask.sum()),
        "fit_source_target_pairs": int(slots * frames),
        "fit": "one proper closed-form Sim(3) over all selected valid clip correspondences",
        "reuse": "same transform for every source/target/visibility/late subset",
        "oracle": True,
    }
    return results


def merge_pooled(destination: dict[str, dict[str, float]],
                 metrics: dict[str, dict[str, float | int]]) -> None:
    for name, value in metrics.items():
        row = destination.setdefault(name, {"sum": 0.0, "points": 0.0})
        row["sum"] += float(value["epe_m"]) * int(value["points"])
        row["points"] += int(value["points"])


def finish_pooled(store: dict[str, dict[str, float]]) -> dict[str, dict[str, float | int]]:
    return _finish(store)
