# 4RC 原生 512 / 147 段评估代码

这是历史 0.3397141295555015 m 结果对应的源码导出，不是重新评估。
WorldBridge 导出版本见 PROVENANCE.json；所有导出的历史文件保持 Git blob 原始字节。
上游 4RC 源码在 vendor/4rc，保留原始 LICENSE。

## 协议
MOVi-F 原生 512x512 validation，147 段，每段前 21 帧；全部 441 个源/目标帧对。
展平像素索引 stride=16，每帧对筛选前 16,384 点；WorldBridge validity A 保留遮挡有效点。
每段全部有效点联合拟合一套 proper 闭式 Umeyama Sim(3)，所有子集共用。
主指标是全部有效对应点 pooled 3D EPE（米）；不是官方 50 段 RANSAC 协议。
历史 pooled EPE=0.3397141295555015 m；有效对应点数=1,062,124,350。

## 核心文件
- scripts/run_4rc_kubric_validation.py：推理和整套评估入口
- scripts/evaluate_4rc_kubric.py：TFRecord/GT/评分适配
- src/worldbridge/evaluation512.py：采样、闭式 Sim(3)、指标
- src/worldbridge/data.py、geometry.py：原生数据和几何
- docs/NATIVE_512_CONTEMPORARY_EVALUATION.md：原始协议与命令
- tests/test_st4rtrack_sim3.py：名称沿用历史，实际测试共享 native-512/Sim(3) 实现

为保留历史 __init__.py 的导入依赖，包含了该提交的完整 src，而不只是上述几个文件。

## 环境和外部文件
不包含模型权重、数据集、预测文件或历史逐片段结果。
需要自行准备原生 MOVi-F 512 TFRecords 和 Hugging Face Luo-Yihang/4RC 权重：
权重 revision=3634b324abb16634a527987c8efa212e392a1449。

requirements.txt 和 vendor/4rc/requirements.txt 是两个项目当时的依赖声明，
不是那次 Run 的完整 pip-freeze，也不保证可直接合并安装。
历史运行曾补装 addict，并使用 NumPy 1.26.4 解决 TensorFlow ABI 问题。
需要匹配本机 CUDA 的 PyTorch、TensorFlow TFRecord protobuf、Pillow 及上游运行依赖。
这里只验证导出完整性；没有重新安装环境或跑 GPU 推理。

## 运行（在解压后的目录内，准备好环境、数据、权重后）
```bash
python scripts/run_4rc_kubric_validation.py \
  --fourrc-root "$PWD/vendor/4rc" \
  --checkpoint-dir /absolute/path/to/4RC-checkpoint \
  --data-root /absolute/path/to/MOVi-F/512x512 \
  --split validation --max-clips 147 \
  --clip-start 0 --clip-length 21 --size 512 --patch-size 14 \
  --pixel-stride 16 \
  --output /absolute/path/to/results/4rc_validation147.json
```
在调度系统或 shell 中显式选择有权限使用的 GPU；此包不会启动或分配 GPU。
入口没有显式 seed 参数；没有补造原运行的随机种子。

建议先将 --max-clips 改为 1，输出写到独立 smoke 文件，再跑全量。
共享几何单元测试（环境完整时）：
```bash
PYTHONPATH=src pytest -q tests/test_st4rtrack_sim3.py tests/test_geometry.py
```

校验全部文件：`sha256sum -c SHA256SUMS`。
