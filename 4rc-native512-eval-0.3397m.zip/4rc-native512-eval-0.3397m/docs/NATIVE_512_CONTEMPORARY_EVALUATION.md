# Native-512 contemporary-method evaluation

This protocol replaces the historical native-128 MOVi-F evaluations for
St4RTrack, 4RC, and Any4D. Old numbers remain historical and must not be mixed
with native-512 results.

## Fixed contract

- Input geometry release: `/dataset/nas0/yejun/MOVi-F/512x512`, explicit resolution check.
- Split: validation; frames `0..20`; no crop of native square clips.
- Sources: all `0..20`; targets: all `0..20`; 441 ordered pairs per clip.
- Metric pixels: flat native-512 stride 16, 16,384 source pixels per pair.
- Validity: WorldBridge `A`; target-occluded but geometrically valid points stay.
- Coordinates: prediction and GT are compared in the common frame-0 Kubric
  camera basis.
- Alignment: report raw EPE and one proper closed-form Sim(3) per clip. Fit over
  all selected valid points in all pairs and reuse the transform for every
  subset. Name it `clip_sim3_closed`; it is oracle GT alignment, not 4RC's
  separate RANSAC protocol.

Do not resize 128 RGB/GT to 512, downsample predictions to 128, select only
`source=0`, or fit a transform per pair/subset.

## Released preprocessing

- St4RTrack: native 512 input and native 512 output grid, no crop.
- 4RC: native 512 RGB; map native source-pixel coordinates directly to its
  released patch output grid (normally 504 square). There is no 128 grid.
- Any4D: official 518 square preprocessing; map output once to the native 512
  metric grid with documented half-pixel bilinear semantics.

## Formal commands

Outputs are written outside Git.

```bash
python scripts/evaluate_st4rtrack_kubric.py \
  --data-root /dataset/nas0/yejun/MOVi-F/512x512 \
  --max-examples 32 --pixel-stride 16 --batch-size 2 \
  --output /data/WorldBridge4D-runs/native512/st4rtrack_validation32.json

python scripts/run_4rc_kubric_validation.py \
  --data-root /dataset/nas0/yejun/MOVi-F/512x512 \
  --max-clips 147 --pixel-stride 16 \
  --output /data/WorldBridge4D-runs/native512/4rc_validation147.json

python scripts/evaluate_any4d_kubric.py \
  --data-root /dataset/nas0/yejun/MOVi-F/512x512 \
  --max-clips 147 --sources all --pixel-stride 16 \
  --output /data/WorldBridge4D-runs/native512/any4d_validation147_all_source.json
```

Before formal runs, each method must pass a one-clip smoke with the same flags.
Record code revision, released checkpoint revision/checksum, GPU, runtime,
processed clip IDs, model input/output grids, and the full per-clip transform.
